package com.example.blog.repository;

import com.example.blog.model.Blog;

import java.util.List;

public interface IBlogRepository extends IGeneralRepository<Blog> {
}
