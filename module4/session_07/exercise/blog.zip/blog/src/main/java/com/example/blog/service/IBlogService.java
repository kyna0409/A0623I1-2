package com.example.blog.service;

import com.example.blog.model.Blog;

public interface IBlogService extends IGeneralService<Blog> {

}
